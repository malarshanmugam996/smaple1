package com.example.cabin_booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
