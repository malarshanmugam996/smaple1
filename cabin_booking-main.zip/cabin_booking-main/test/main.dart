import 'model/main.dart' as model_test;
import 'utils/main.dart' as utils_test;

void main() {
  model_test.main();
  utils_test.main();
}
